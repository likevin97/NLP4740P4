# Baseline

## Install

Install libraries

- NLTK
- NLTK (punkt)
- NLTK (averaged_perceptron_tagger)

## Usage

Open the jupyter notebook `Main.ipynb` and just execute the code cell by cell.
The output file is by default `output.json`

- To change the train file change the file to open in the 3rd cell from `development.json`
- to change output file change the file to open in the 4th cell from `output.json`
